from django.apps import AppConfig


class AutomobilsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'automobils'
