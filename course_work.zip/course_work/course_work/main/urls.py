from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),
    path('automobils',views.about, name='auto'),
    path('contacts',views.contacts, name='contacts')
]
